# Bubble Pop Adventure (Android)

A small offline Android game wrapper around the Bubble Pop Adventure game.

## Build an APK
1. Install Android Studio on a computer from https://developer.android.com/studio
2. Extract this ZIP.
3. In Android Studio, choose **Open** and select the extracted `BubblePopAdventureAndroid` folder.
4. Allow Gradle sync and install the Android SDK requested by Android Studio.
5. Select **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
6. When the build finishes, click **locate** in the notification. The APK is normally at `app/build/outputs/apk/debug/app-debug.apk`.
7. Transfer the APK to your Android phone and open it to install. Android may ask you to allow installs from that source.

The game works offline and requests no internet permission. The APK is not prebuilt in this ZIP because an Android SDK/Gradle build environment was not available here.
